'use strict';

import { IsBoolean, IsOptional } from 'class-validator';

export class RunComplianceEngineDto {
  @IsOptional()
  @IsBoolean()
  persist?: boolean;

  @IsOptional()
  @IsBoolean()
  resolveStaleEngineChecks?: boolean;
}
